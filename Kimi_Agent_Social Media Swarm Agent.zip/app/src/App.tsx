import { useState, useEffect } from 'react';
import { 
  Activity, 
  TrendingUp, 
  Video, 
  Image, 
  CheckCircle, 
  Clock,
  Youtube,
  Facebook,
  Music2,
  Zap,
  BarChart3,
  Settings,
  RefreshCw
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AgentStatusCard } from '@/components/AgentStatusCard';
import { PostTimeline } from '@/components/PostTimeline';
import { PlatformStats } from '@/components/PlatformStats';
import './App.css';

interface DashboardStats {
  totalPosts: number;
  postsToday: number;
  dailyLimit: number;
  successRate: number;
  activeAgents: number;
  lastScan: string;
  nextScan: string;
  platformBreakdown: {
    youtube: number;
    tiktok: number;
    facebook: number;
  };
}

interface Agent {
  id: string;
  name: string;
  status: 'active' | 'idle' | 'error';
  lastRun: string;
  nextRun: string;
  icon: React.ReactNode;
  color: string;
}

interface ActivityLog {
  id: string;
  timestamp: string;
  agent: string;
  action: string;
  status: 'success' | 'error' | 'warning';
  details: string;
}

function App() {
  const [stats, setStats] = useState<DashboardStats>({
    totalPosts: 0,
    postsToday: 0,
    dailyLimit: 15,
    successRate: 0,
    activeAgents: 4,
    lastScan: '-',
    nextScan: '-',
    platformBreakdown: { youtube: 0, tiktok: 0, facebook: 0 }
  });

  const [agents] = useState<Agent[]>([
    {
      id: 'trend-scout',
      name: 'Trend Scout',
      status: 'active',
      lastRun: '2 hours ago',
      nextRun: 'in 2 hours',
      icon: <TrendingUp className="w-5 h-5" />,
      color: 'bg-blue-500'
    },
    {
      id: 'content-creator',
      name: 'Content Creator',
      status: 'idle',
      lastRun: '4 hours ago',
      nextRun: 'on demand',
      icon: <Zap className="w-5 h-5" />,
      color: 'bg-purple-500'
    },
    {
      id: 'visual-editor',
      name: 'Visual Editor',
      status: 'idle',
      lastRun: '4 hours ago',
      nextRun: 'on demand',
      icon: <Image className="w-5 h-5" />,
      color: 'bg-pink-500'
    },
    {
      id: 'compliance-bot',
      name: 'Compliance Bot',
      status: 'active',
      lastRun: '30 mins ago',
      nextRun: 'continuous',
      icon: <CheckCircle className="w-5 h-5" />,
      color: 'bg-green-500'
    }
  ]);

  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([
    {
      id: '1',
      timestamp: '2024-01-15 14:30:00',
      agent: 'Trend Scout',
      action: 'Viral Scan Complete',
      status: 'success',
      details: 'Found 5 trending topics'
    },
    {
      id: '2',
      timestamp: '2024-01-15 14:35:00',
      agent: 'Content Creator',
      action: 'Content Generated',
      status: 'success',
      details: 'Created 5 posts for all platforms'
    },
    {
      id: '3',
      timestamp: '2024-01-15 14:40:00',
      agent: 'Visual Editor',
      action: 'Assets Created',
      status: 'success',
      details: 'Generated 15 images, 5 videos'
    },
    {
      id: '4',
      timestamp: '2024-01-15 14:45:00',
      agent: 'Compliance Bot',
      action: 'Content Approved',
      status: 'success',
      details: 'All 5 posts passed compliance'
    },
    {
      id: '5',
      timestamp: '2024-01-15 15:00:00',
      agent: 'YouTube Publisher',
      action: 'Post Published',
      status: 'success',
      details: 'Video ID: abc123'
    }
  ]);

  const [isRefreshing, setIsRefreshing] = useState(false);

  const refreshData = () => {
    setIsRefreshing(true);
    // Simulate data refresh
    setTimeout(() => {
      setStats(prev => ({
        ...prev,
        postsToday: Math.min(prev.postsToday + 1, 15),
        totalPosts: prev.totalPosts + 1
      }));
      setIsRefreshing(false);
    }, 1500);
  };

  const triggerManualScan = () => {
    const newLog: ActivityLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      agent: 'Orchestrator',
      action: 'Manual Scan Triggered',
      status: 'success',
      details: 'Viral scan initiated by user'
    };
    setActivityLogs([newLog, ...activityLogs]);
  };

  useEffect(() => {
    // Simulate initial data load
    setStats({
      totalPosts: 127,
      postsToday: 8,
      dailyLimit: 15,
      successRate: 94,
      activeAgents: 4,
      lastScan: '2 hours ago',
      nextScan: 'in 2 hours',
      platformBreakdown: { youtube: 42, tiktok: 45, facebook: 40 }
    });
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-500';
      case 'error': return 'bg-red-500';
      case 'warning': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-slate-700/50 bg-slate-900/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
                  Harry Agent Swarm
                </h1>
                <p className="text-sm text-slate-400">Social Media Automation Dashboard</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={refreshData}
                disabled={isRefreshing}
                className="border-slate-600 hover:bg-slate-800"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Button 
                size="sm" 
                onClick={triggerManualScan}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Zap className="w-4 h-4 mr-2" />
                Trigger Scan
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Posts Today</p>
                  <p className="text-3xl font-bold mt-1">
                    {stats.postsToday}<span className="text-lg text-slate-500">/{stats.dailyLimit}</span>
                  </p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-blue-500/20 flex items-center justify-center">
                  <Video className="w-6 h-6 text-blue-400" />
                </div>
              </div>
              <Progress value={(stats.postsToday / stats.dailyLimit) * 100} className="mt-4" />
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Total Posts</p>
                  <p className="text-3xl font-bold mt-1">{stats.totalPosts}</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-purple-500/20 flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-purple-400" />
                </div>
              </div>
              <p className="text-sm text-green-400 mt-4 flex items-center">
                <TrendingUp className="w-4 h-4 mr-1" />
                +12% this week
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Success Rate</p>
                  <p className="text-3xl font-bold mt-1">{stats.successRate}%</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-green-500/20 flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-400" />
                </div>
              </div>
              <p className="text-sm text-slate-400 mt-4">Last 30 days</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Active Agents</p>
                  <p className="text-3xl font-bold mt-1">{stats.activeAgents}/4</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-orange-500/20 flex items-center justify-center">
                  <Activity className="w-6 h-6 text-orange-400" />
                </div>
              </div>
              <p className="text-sm text-slate-400 mt-4">
                <Clock className="w-4 h-4 inline mr-1" />
                Next scan: {stats.nextScan}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Agents & Activity */}
          <div className="lg:col-span-2 space-y-6">
            {/* Agent Status */}
            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-400" />
                  Agent Status
                </CardTitle>
                <CardDescription>Real-time status of all swarm agents</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {agents.map(agent => (
                    <AgentStatusCard key={agent.id} agent={agent} />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Activity Timeline */}
            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-purple-400" />
                  Activity Log
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-80">
                  <div className="space-y-3">
                    {activityLogs.map((log) => (
                      <div 
                        key={log.id} 
                        className="flex items-start gap-3 p-3 rounded-lg bg-slate-700/30 hover:bg-slate-700/50 transition-colors"
                      >
                        <div className={`w-2 h-2 rounded-full mt-2 ${getStatusColor(log.status)}`} />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-medium text-sm">{log.action}</p>
                            <span className="text-xs text-slate-500">{log.timestamp}</span>
                          </div>
                          <p className="text-xs text-slate-400">{log.agent}</p>
                          <p className="text-xs text-slate-500 mt-1">{log.details}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Platform Stats */}
          <div className="space-y-6">
            {/* Platform Breakdown */}
            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-green-400" />
                  Platform Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <PlatformStats breakdown={stats.platformBreakdown} />
              </CardContent>
            </Card>

            {/* Post Timeline */}
            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-pink-400" />
                  Posting Schedule
                </CardTitle>
              </CardHeader>
              <CardContent>
                <PostTimeline postsToday={stats.postsToday} limit={stats.dailyLimit} />
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-orange-400" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start border-slate-600 hover:bg-slate-700">
                    <Youtube className="w-4 h-4 mr-2 text-red-400" />
                    View YouTube Channel
                  </Button>
                  <Button variant="outline" className="w-full justify-start border-slate-600 hover:bg-slate-700">
                    <Music2 className="w-4 h-4 mr-2 text-cyan-400" />
                    View TikTok Profile
                  </Button>
                  <Button variant="outline" className="w-full justify-start border-slate-600 hover:bg-slate-700">
                    <Facebook className="w-4 h-4 mr-2 text-blue-400" />
                    View Facebook Page
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Tabs Section */}
        <Tabs defaultValue="overview" className="mt-8">
          <TabsList className="bg-slate-800/50 border border-slate-700/50">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="content">Content Queue</TabsTrigger>
            <TabsTrigger value="compliance">Compliance</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
              <CardHeader>
                <CardTitle>24-Hour Plan</CardTitle>
                <CardDescription>Automated content schedule for the next 24 hours</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="p-4 rounded-lg bg-slate-700/30">
                    <div className="flex items-center gap-2 mb-3">
                      <Clock className="w-5 h-5 text-blue-400" />
                      <h3 className="font-semibold">Window 1 (00:00-08:00)</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-slate-400">
                      <li className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">Scheduled</Badge>
                        5 posts across platforms
                      </li>
                      <li>• 2 YouTube Shorts</li>
                      <li>• 2 TikTok Videos</li>
                      <li>• 1 Facebook Post</li>
                    </ul>
                  </div>
                  <div className="p-4 rounded-lg bg-slate-700/30">
                    <div className="flex items-center gap-2 mb-3">
                      <Clock className="w-5 h-5 text-purple-400" />
                      <h3 className="font-semibold">Window 2 (08:00-16:00)</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-slate-400">
                      <li className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">Scheduled</Badge>
                        5 posts across platforms
                      </li>
                      <li>• 2 YouTube Shorts</li>
                      <li>• 2 TikTok Videos</li>
                      <li>• 1 Facebook Post</li>
                    </ul>
                  </div>
                  <div className="p-4 rounded-lg bg-slate-700/30">
                    <div className="flex items-center gap-2 mb-3">
                      <Clock className="w-5 h-5 text-pink-400" />
                      <h3 className="font-semibold">Window 3 (16:00-24:00)</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-slate-400">
                      <li className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">Scheduled</Badge>
                        5 posts across platforms
                      </li>
                      <li>• 1 YouTube Short</li>
                      <li>• 2 TikTok Videos</li>
                      <li>• 2 Facebook Posts</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="content" className="mt-6">
            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Content Queue</CardTitle>
                <CardDescription>Pending and scheduled content</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-700/30">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
                        <Youtube className="w-5 h-5 text-red-400" />
                      </div>
                      <div>
                        <p className="font-medium">"Top 5 Viral Trends This Week"</p>
                        <p className="text-sm text-slate-400">YouTube Short • Scheduled for 16:00</p>
                      </div>
                    </div>
                    <Badge className="bg-yellow-500/20 text-yellow-400">Pending Review</Badge>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-700/30">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                        <Music2 className="w-5 h-5 text-cyan-400" />
                      </div>
                      <div>
                        <p className="font-medium">"Reacting to Viral Challenges"</p>
                        <p className="text-sm text-slate-400">TikTok Video • Scheduled for 18:00</p>
                      </div>
                    </div>
                    <Badge className="bg-green-500/20 text-green-400">Approved</Badge>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-700/30">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                        <Facebook className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <p className="font-medium">"Discussion: What's Your Take?"</p>
                        <p className="text-sm text-slate-400">Facebook Post • Scheduled for 20:00</p>
                      </div>
                    </div>
                    <Badge className="bg-green-500/20 text-green-400">Approved</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="compliance" className="mt-6">
            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Compliance Status</CardTitle>
                <CardDescription>Content moderation and guideline adherence</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/30">
                      <p className="text-2xl font-bold text-green-400">98.5%</p>
                      <p className="text-sm text-slate-400">Pass Rate</p>
                    </div>
                    <div className="p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                      <p className="text-2xl font-bold text-yellow-400">2</p>
                      <p className="text-sm text-slate-400">Flagged (Pending)</p>
                    </div>
                    <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/30">
                      <p className="text-2xl font-bold text-red-400">0</p>
                      <p className="text-sm text-slate-400">Rejected (24h)</p>
                    </div>
                  </div>
                  <Separator className="bg-slate-700" />
                  <div className="space-y-2">
                    <h4 className="font-medium">Recent Compliance Checks</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-3 rounded-lg bg-slate-700/30">
                        <span className="text-sm">Content ID: #12345</span>
                        <Badge className="bg-green-500/20 text-green-400">Approved</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 rounded-lg bg-slate-700/30">
                        <span className="text-sm">Content ID: #12346</span>
                        <Badge className="bg-green-500/20 text-green-400">Approved</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 rounded-lg bg-slate-700/30">
                        <span className="text-sm">Content ID: #12347</span>
                        <Badge className="bg-yellow-500/20 text-yellow-400">Under Review</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="mt-6">
            <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Workflow Settings</CardTitle>
                <CardDescription>Configure automation parameters</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Daily Post Limit</label>
                      <input 
                        type="number" 
                        value="15" 
                        className="w-full px-3 py-2 rounded-lg bg-slate-700 border border-slate-600 text-white"
                        readOnly
                      />
                      <p className="text-xs text-slate-500 mt-1">Maximum posts per day across all platforms</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Scan Interval</label>
                      <select className="w-full px-3 py-2 rounded-lg bg-slate-700 border border-slate-600 text-white">
                        <option>Every 4 hours</option>
                        <option>Every 2 hours</option>
                        <option>Every 6 hours</option>
                        <option>Every 8 hours</option>
                      </select>
                      <p className="text-xs text-slate-500 mt-1">How often to scan for viral trends</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Content Niche</label>
                      <select className="w-full px-3 py-2 rounded-lg bg-slate-700 border border-slate-600 text-white">
                        <option>Auto-detect</option>
                        <option>Entertainment</option>
                        <option>Education</option>
                        <option>Technology</option>
                        <option>Lifestyle</option>
                      </select>
                      <p className="text-xs text-slate-500 mt-1">Primary content category</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">AI Generation</label>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" checked className="w-4 h-4 rounded border-slate-600" readOnly />
                        <span className="text-sm">Enable AI image/video generation</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">Use DALL-E and Runway ML for assets</p>
                    </div>
                  </div>
                  <Separator className="bg-slate-700" />
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Workflow Status</p>
                      <p className="text-sm text-slate-400">Main orchestrator is currently active</p>
                    </div>
                    <Badge className="bg-green-500/20 text-green-400 px-3 py-1">Active</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

export default App;