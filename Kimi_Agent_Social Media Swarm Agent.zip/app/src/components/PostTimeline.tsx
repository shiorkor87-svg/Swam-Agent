import { CheckCircle, Clock, Circle } from 'lucide-react';

interface PostTimelineProps {
  postsToday: number;
  limit: number;
}

export function PostTimeline({ postsToday, limit }: PostTimelineProps) {
  // Create 15 slots for the day
  const slots = Array.from({ length: limit }, (_, i) => {
    const hour = Math.floor((i / limit) * 24);
    const minute = ((i % 3) * 20).toString().padStart(2, '0');
    const time = `${hour.toString().padStart(2, '0')}:${minute}`;
    const isPosted = i < postsToday;
    const isNext = i === postsToday;
    
    return {
      id: i,
      time,
      status: isPosted ? 'posted' : isNext ? 'next' : 'pending'
    };
  });

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm mb-4">
        <span className="text-slate-400">Daily Schedule</span>
        <span className="text-slate-400">{postsToday}/{limit} posted</span>
      </div>
      <div className="space-y-1 max-h-64 overflow-y-auto">
        {slots.map((slot) => (
          <div 
            key={slot.id}
            className={`flex items-center gap-3 p-2 rounded-lg text-sm ${
              slot.status === 'posted' 
                ? 'bg-green-500/10' 
                : slot.status === 'next'
                ? 'bg-blue-500/10 border border-blue-500/30'
                : 'bg-slate-700/30'
            }`}
          >
            {slot.status === 'posted' ? (
              <CheckCircle className="w-4 h-4 text-green-400" />
            ) : slot.status === 'next' ? (
              <Clock className="w-4 h-4 text-blue-400" />
            ) : (
              <Circle className="w-4 h-4 text-slate-500" />
            )}
            <span className="text-slate-400 w-12">{slot.time}</span>
            <span className={
              slot.status === 'posted' 
                ? 'text-green-400' 
                : slot.status === 'next'
                ? 'text-blue-400'
                : 'text-slate-500'
            }>
              {slot.status === 'posted' 
                ? 'Posted' 
                : slot.status === 'next'
                ? 'Next'
                : 'Scheduled'}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}