import { Youtube, Facebook, Music2 } from 'lucide-react';

interface PlatformBreakdown {
  youtube: number;
  tiktok: number;
  facebook: number;
}

interface PlatformStatsProps {
  breakdown: PlatformBreakdown;
}

export function PlatformStats({ breakdown }: PlatformStatsProps) {
  const total = breakdown.youtube + breakdown.tiktok + breakdown.facebook;
  
  const platforms = [
    {
      name: 'YouTube',
      icon: <Youtube className="w-5 h-5" />,
      count: breakdown.youtube,
      percentage: total > 0 ? (breakdown.youtube / total) * 100 : 0,
      color: 'bg-red-500',
      textColor: 'text-red-400',
      bgColor: 'bg-red-500/20'
    },
    {
      name: 'TikTok',
      icon: <Music2 className="w-5 h-5" />,
      count: breakdown.tiktok,
      percentage: total > 0 ? (breakdown.tiktok / total) * 100 : 0,
      color: 'bg-cyan-500',
      textColor: 'text-cyan-400',
      bgColor: 'bg-cyan-500/20'
    },
    {
      name: 'Facebook',
      icon: <Facebook className="w-5 h-5" />,
      count: breakdown.facebook,
      percentage: total > 0 ? (breakdown.facebook / total) * 100 : 0,
      color: 'bg-blue-500',
      textColor: 'text-blue-400',
      bgColor: 'bg-blue-500/20'
    }
  ];

  return (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <p className="text-3xl font-bold">{total}</p>
        <p className="text-sm text-slate-400">Total Posts</p>
      </div>
      
      {platforms.map((platform) => (
        <div key={platform.name} className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-lg ${platform.bgColor} flex items-center justify-center ${platform.textColor}`}>
                {platform.icon}
              </div>
              <div>
                <p className="font-medium text-sm">{platform.name}</p>
                <p className="text-xs text-slate-400">{platform.count} posts</p>
              </div>
            </div>
            <span className={`text-sm font-medium ${platform.textColor}`}>
              {platform.percentage.toFixed(0)}%
            </span>
          </div>
          <div className="h-2 rounded-full bg-slate-700 overflow-hidden">
            <div 
              className={`h-full ${platform.color} transition-all duration-500`}
              style={{ width: `${platform.percentage}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}