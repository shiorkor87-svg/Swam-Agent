import { Activity, AlertTriangle, Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface Agent {
  id: string;
  name: string;
  status: 'active' | 'idle' | 'error';
  lastRun: string;
  nextRun: string;
  icon: React.ReactNode;
  color: string;
}

interface AgentStatusCardProps {
  agent: Agent;
}

export function AgentStatusCard({ agent }: AgentStatusCardProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            <Activity className="w-3 h-3 mr-1" />
            Active
          </Badge>
        );
      case 'idle':
        return (
          <Badge className="bg-slate-500/20 text-slate-400 border-slate-500/30">
            <Clock className="w-3 h-3 mr-1" />
            Idle
          </Badge>
        );
      case 'error':
        return (
          <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
            <AlertTriangle className="w-3 h-3 mr-1" />
            Error
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex items-center gap-4 p-4 rounded-lg bg-slate-700/30 hover:bg-slate-700/50 transition-colors">
      <div className={`w-10 h-10 rounded-lg ${agent.color}/20 flex items-center justify-center`}>
        <div className={`${agent.color.replace('bg-', 'text-')}`}>
          {agent.icon}
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <p className="font-medium text-sm truncate">{agent.name}</p>
          {getStatusBadge(agent.status)}
        </div>
        <div className="flex items-center gap-4 mt-1 text-xs text-slate-400">
          <span>Last: {agent.lastRun}</span>
          <span>Next: {agent.nextRun}</span>
        </div>
      </div>
    </div>
  );
}