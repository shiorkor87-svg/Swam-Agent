# Harry Agent Swarm - Social Media Automation

A comprehensive n8n-based automation system that manages 15 posts per day across YouTube, TikTok, and Facebook using an intelligent agent swarm architecture.

## Overview

The Harry Agent Swarm is an autonomous social media content factory that:
- **Scans for viral trends** every 4 hours
- **Generates 5 unique content pieces** per 8-hour window (15/day total)
- **Creates platform-optimized content** for YouTube Shorts, TikTok videos, and Facebook posts
- **Ensures compliance** with platform guidelines
- **Publishes automatically** to all platforms

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    MAIN ORCHESTRATOR                            │
│              (Schedule: Every 4 hours)                          │
└────────────────────┬────────────────────────────────────────────┘
                     │
        ┌────────────┼────────────┐
        │            │            │
        ▼            ▼            ▼
┌──────────┐  ┌──────────┐  ┌──────────┐
│  Trend   │  │ Content  │  │  Visual  │
│  Scout   │─▶│ Creator  │─▶│  Editor  │
└──────────┘  └──────────┘  └──────────┘
                                    │
                                    ▼
                           ┌──────────┐
                           │Compliance│
                           │   Bot    │
                           └────┬─────┘
                                │
              ┌─────────────────┼─────────────────┐
              │                 │                 │
              ▼                 ▼                 ▼
        ┌──────────┐     ┌──────────┐     ┌──────────┐
        │ YouTube  │     │  TikTok  │     │ Facebook │
        │  Shorts  │     │  Video   │     │   Post   │
        └──────────┘     └──────────┘     └──────────┘
```

## Agent Swarm Components

### 1. Trend Scout Agent
- **Purpose**: Discovers viral topics in real-time
- **Sources**: YouTube Trending, TikTok Trending, Facebook Topics, Google Trends
- **Output**: Ranked list of viral topics with engagement scores

### 2. Content Creator Agent
- **Purpose**: Generates scripts, captions, and storyboards
- **Capabilities**:
  - Platform-specific script writing
  - Hashtag optimization
  - Image prompt generation
  - Video storyboard creation
- **Output**: Complete content package for all platforms

### 3. Visual Editor Agent
- **Purpose**: Creates visual assets using AI
- **Integrations**:
  - DALL-E for image generation
  - Runway ML for video generation
  - ElevenLabs for voiceover
- **Output**: Thumbnails, videos, and supporting images

### 4. Compliance Bot
- **Purpose**: Ensures content meets platform guidelines
- **Checks**:
  - Prohibited content detection
  - Spam indicator analysis
  - Engagement bait detection
  - Daily post limit enforcement (15/day)
- **Output**: Approval/rejection with reasons

## Workflow Files

| File | Description |
|------|-------------|
| `main-orchestrator-workflow.json` | Main workflow that coordinates all agents |
| `sub-agent-trend-scout.json` | Trend discovery and analysis |
| `sub-agent-content-creator.json` | Content generation |
| `sub-agent-visual-editor.json` | Visual asset creation |
| `sub-agent-compliance-bot.json` | Compliance checking |
| `post-to-youtube.json` | YouTube publishing |
| `post-to-tiktok.json` | TikTok publishing |
| `post-to-facebook.json` | Facebook publishing |

## Prerequisites

### Required Accounts & APIs

1. **n8n Instance**
   - Self-hosted or n8n Cloud
   - Version 1.0 or higher

2. **YouTube Data API v3**
   - Google Cloud Console project
   - OAuth 2.0 credentials
   - API key for public data

3. **TikTok Business API**
   - TikTok Developer account
   - Business account connected
   - Access token

4. **Facebook Graph API**
   - Facebook Developer account
   - Facebook Page (admin access)
   - Page access token

5. **AI Services (Optional)**
   - OpenAI API key (DALL-E)
   - Runway ML API key
   - ElevenLabs API key

6. **Database**
   - PostgreSQL instance
   - Connection credentials

## Installation

### Step 1: Set Up n8n

```bash
# Using Docker
docker run -it --rm \
  --name n8n \
  -p 5678:5678 \
  -v ~/.n8n:/home/node/.n8n \
  n8nio/n8n

# Or install globally
npm install n8n -g
n8n start
```

### Step 2: Import Workflows

1. Open n8n at `http://localhost:5678`
2. Go to **Workflows** → **Import from File**
3. Import in this order:
   1. `sub-agent-trend-scout.json`
   2. `sub-agent-content-creator.json`
   3. `sub-agent-visual-editor.json`
   4. `sub-agent-compliance-bot.json`
   5. `post-to-youtube.json`
   6. `post-to-tiktok.json`
   7. `post-to-facebook.json`
   8. `main-orchestrator-workflow.json`

### Step 3: Configure Credentials

In n8n, go to **Settings** → **Credentials** and add:

#### YouTube API
- Name: `youtubeApiKey`
- Type: HTTP Header Auth
- Value: Your YouTube Data API key

#### TikTok API
- Name: `tiktokAccessToken`
- Type: HTTP Header Auth
- Value: Your TikTok access token

#### Facebook API
- Name: `facebookAccessToken`
- Type: HTTP Header Auth
- Value: Your Facebook Page access token
- Also add `facebookPageId` credential

#### OpenAI (for image generation)
- Name: `openaiApiKey`
- Type: HTTP Header Auth
- Value: Your OpenAI API key

#### PostgreSQL
- Name: `postgresCredentials`
- Type: Postgres
- Host, Port, Database, User, Password

### Step 4: Set Up Database Tables

```sql
-- Trend scans table
CREATE TABLE trend_scans (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    topics JSONB,
    categories JSONB,
    top_recommendation JSONB
);

-- Content queue table
CREATE TABLE content_queue (
    id SERIAL PRIMARY KEY,
    content_id VARCHAR(255) UNIQUE,
    topic JSONB,
    platforms JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50)
);

-- Asset library table
CREATE TABLE asset_library (
    id SERIAL PRIMARY KEY,
    content_id VARCHAR(255),
    assets JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50)
);

-- Compliance log table
CREATE TABLE compliance_log (
    id SERIAL PRIMARY KEY,
    content_id VARCHAR(255),
    status VARCHAR(50),
    platform_checks JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ai_review TEXT
);

-- Published posts table
CREATE TABLE published_posts (
    id SERIAL PRIMARY KEY,
    platform VARCHAR(50),
    post_id VARCHAR(255),
    url TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50)
);

-- Quarantined content table
CREATE TABLE quarantined_content (
    id SERIAL PRIMARY KEY,
    content JSONB,
    reason TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'pending_review'
);
```

### Step 5: Activate Workflows

1. Open each workflow in n8n
2. Click **Activate** toggle
3. For main orchestrator, verify the schedule is set to every 4 hours

## Configuration

### Adjusting Post Frequency

Edit `main-orchestrator-workflow.json`:

```javascript
const workflowConfig = {
  dailyPostLimit: 15,      // Change this
  postsPerWindow: 5,       // Posts per 8-hour window
  platforms: ['youtube', 'tiktok', 'facebook']
};
```

### Modifying Schedule

In the **Viral Scan Scheduler** node:
- Default: Every 4 hours
- Options: Every hour, Every 2 hours, Custom cron

### Content Niche Configuration

Edit `sub-agent-trend-scout.json` to filter by category:

```javascript
const contentCategories = {
  entertainment: [...],
  education: [...],
  lifestyle: [...],
  tech: [...],
  // Add your niche categories
};
```

## Usage

### Manual Trigger

1. Open **Main Orchestrator** workflow
2. Click **Execute Workflow**
3. Monitor execution in real-time

### Automatic Operation

Once activated, the system will:
1. Run every 4 hours automatically
2. Scan for trending topics
3. Generate content for all platforms
4. Create visual assets
5. Check compliance
6. Publish approved content
7. Log all activities

### Monitoring

Check these tables for status:

```sql
-- View recent posts
SELECT * FROM published_posts 
ORDER BY timestamp DESC 
LIMIT 10;

-- View daily stats
SELECT platform, COUNT(*) 
FROM published_posts 
WHERE DATE(timestamp) = CURRENT_DATE 
GROUP BY platform;

-- View quarantined content
SELECT * FROM quarantined_content 
WHERE status = 'pending_review';
```

## API Integration Details

### YouTube Data API

**Scopes Required:**
- `https://www.googleapis.com/auth/youtube.upload`
- `https://www.googleapis.com/auth/youtube.readonly`

**Rate Limits:**
- 10,000 units per day
- Video upload: 1600 units

### TikTok Business API

**Scopes Required:**
- `video.upload`
- `video.list`

**Rate Limits:**
- 1000 requests per day

### Facebook Graph API

**Scopes Required:**
- `pages_manage_posts`
- `pages_read_engagement`

**Rate Limits:**
- 200 calls/hour per user

## Troubleshooting

### Common Issues

#### 1. API Authentication Errors
```
Error: Invalid credentials
```
**Solution:** Verify credentials in n8n settings. Re-authenticate OAuth apps.

#### 2. Rate Limiting
```
Error: Rate limit exceeded
```
**Solution:** Add delay nodes between API calls. Check rate limit headers.

#### 3. Content Rejected
```
Compliance Bot: Content rejected
```
**Solution:** Check `compliance_log` table for rejection reason. Adjust content.

#### 4. Missing Assets
```
Visual Editor: No assets generated
```
**Solution:** Verify API keys for DALL-E/Runway. Check fallback assets are enabled.

### Debug Mode

Enable verbose logging by adding to any Code node:

```javascript
console.log('Debug:', JSON.stringify(data, null, 2));
```

View logs in n8n: **Settings** → **Execution Log**

## Security Considerations

1. **Store credentials securely** in n8n, never in workflow files
2. **Use environment variables** for sensitive data
3. **Rotate API keys** regularly
4. **Monitor API usage** for unusual activity
5. **Enable 2FA** on all social media accounts

## Customization

### Adding New Platforms

1. Create new workflow: `post-to-[platform].json`
2. Add platform to `workflowConfig.platforms`
3. Update `sub-agent-content-creator.json` with platform-specific templates
4. Add compliance rules to `sub-agent-compliance-bot.json`

### Custom Content Templates

Edit `sub-agent-content-creator.json`:

```javascript
const contentTemplates = {
  [your_platform]: {
    maxDuration: 120,
    hookDuration: 5,
    style: 'your-custom-style',
    cta: 'Your custom call-to-action'
  }
};
```

## Performance Optimization

### For High Volume

1. **Enable workflow execution concurrency**
2. **Use connection pooling** for database
3. **Cache trend data** (Redis recommended)
4. **Batch API requests** where possible

### Resource Usage

| Component | CPU | Memory | Notes |
|-----------|-----|--------|-------|
| n8n Core | Low | 512MB | Base operation |
| Trend Scout | Medium | 256MB | API calls |
| Content Creator | High | 512MB | AI processing |
| Visual Editor | High | 1GB | Media generation |
| Compliance Bot | Low | 256MB | Text analysis |

## Support & Updates

### Getting Help

1. Check n8n documentation: https://docs.n8n.io
2. Review workflow execution logs
3. Enable debug mode for detailed output

### Updating Workflows

1. Export current workflows as backup
2. Import updated workflow files
3. Reconfigure credentials if needed
4. Test in staging environment first

## License

MIT License - Feel free to modify and distribute.

## Credits

Built with:
- [n8n](https://n8n.io) - Workflow automation
- [OpenAI](https://openai.com) - Image generation
- [Runway ML](https://runwayml.com) - Video generation
- [ElevenLabs](https://elevenlabs.io) - Voice generation