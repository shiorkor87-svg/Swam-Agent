# Harry Agent Swarm - Deployment Guide

## Quick Start

This guide will help you deploy the Harry Agent Swarm automation system in n8n.

## Prerequisites

1. **n8n Instance** - Self-hosted or n8n Cloud
2. **API Credentials** - YouTube, TikTok, Facebook
3. **Database** - PostgreSQL (optional, for logging)

## Step 1: Install n8n

### Option A: Docker (Recommended)

```bash
docker run -it --rm \
  --name n8n \
  -p 5678:5678 \
  -v ~/.n8n:/home/node/.n8n \
  n8nio/n8n
```

### Option B: npm

```bash
npm install n8n -g
n8n start
```

Access n8n at: `http://localhost:5678`

## Step 2: Import Workflows

### Import Order (Important!)

Import workflows in this exact order to avoid dependency issues:

1. **Sub-Agents** (import first)
   - `sub-agent-trend-scout.json`
   - `sub-agent-content-creator.json`
   - `sub-agent-visual-editor.json`
   - `sub-agent-compliance-bot.json`

2. **Platform Publishers** (import second)
   - `post-to-youtube.json`
   - `post-to-tiktok.json`
   - `post-to-facebook.json`

3. **Main Orchestrator** (import last)
   - `main-orchestrator-workflow.json`

### How to Import

1. Open n8n dashboard
2. Click **Workflows** in left sidebar
3. Click **Import from File**
4. Select the JSON file
5. Click **Import**
6. Repeat for all workflow files

## Step 3: Configure Credentials

### YouTube Data API

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project
3. Enable **YouTube Data API v3**
4. Create OAuth 2.0 credentials
5. In n8n: **Settings** → **Credentials** → **New**
6. Select **Google OAuth2 API**
7. Enter Client ID and Client Secret

### TikTok Business API

1. Go to [TikTok for Developers](https://developers.tiktok.com/)
2. Create a developer account
3. Register your app
4. Get access token
5. In n8n: **Settings** → **Credentials** → **New**
6. Select **HTTP Header Auth**
7. Name: `tiktokAccessToken`
8. Value: Your access token

### Facebook Graph API

1. Go to [Facebook Developers](https://developers.facebook.com/)
2. Create a new app
3. Add **Facebook Login** product
4. Get Page Access Token
5. In n8n: **Settings** → **Credentials** → **New**
6. Select **Facebook Graph API**
7. Enter your access token

### OpenAI (Optional - for AI generation)

1. Go to [OpenAI Platform](https://platform.openai.com/)
2. Create API key
3. In n8n: **Settings** → **Credentials** → **New**
4. Select **OpenAI**
5. Enter your API key

### PostgreSQL (Optional - for logging)

1. In n8n: **Settings** → **Credentials** → **New**
2. Select **Postgres**
3. Enter connection details:
   - Host: your-db-host
   - Port: 5432
   - Database: harry_agent_swarm
   - User: your-username
   - Password: your-password

## Step 4: Set Up Database (Optional)

If using PostgreSQL for logging, create these tables:

```sql
-- Run this SQL in your PostgreSQL database

CREATE TABLE trend_scans (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    topics JSONB,
    categories JSONB,
    top_recommendation JSONB
);

CREATE TABLE content_queue (
    id SERIAL PRIMARY KEY,
    content_id VARCHAR(255) UNIQUE,
    topic JSONB,
    platforms JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50)
);

CREATE TABLE asset_library (
    id SERIAL PRIMARY KEY,
    content_id VARCHAR(255),
    assets JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50)
);

CREATE TABLE compliance_log (
    id SERIAL PRIMARY KEY,
    content_id VARCHAR(255),
    status VARCHAR(50),
    platform_checks JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ai_review TEXT
);

CREATE TABLE published_posts (
    id SERIAL PRIMARY KEY,
    platform VARCHAR(50),
    post_id VARCHAR(255),
    url TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50)
);

CREATE TABLE quarantined_content (
    id SERIAL PRIMARY KEY,
    content JSONB,
    reason TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'pending_review'
);
```

## Step 5: Activate Workflows

1. Open each workflow in n8n
2. Click the **Activate** toggle (top right)
3. The main orchestrator will run automatically every 4 hours

## Step 6: Test the System

### Manual Test

1. Open **Main Orchestrator** workflow
2. Click **Execute Workflow** button
3. Monitor the execution in real-time
4. Check logs for any errors

### Verify Sub-Agents

Run each sub-agent individually:

1. Open **Sub-Agent: Trend Scout**
2. Click **Execute Workflow**
3. Verify it returns trending topics
4. Repeat for other sub-agents

## Step 7: Monitor Dashboard

Access the monitoring dashboard at:
**https://qyh72pcmbowdi.ok.kimi.link**

The dashboard shows:
- Real-time agent status
- Posts published today
- Platform breakdown
- Activity logs
- Compliance status

## Configuration Options

### Adjust Post Frequency

Edit **Main Orchestrator** → **Initialize Orchestrator** node:

```javascript
const workflowConfig = {
  dailyPostLimit: 15,    // Change this
  postsPerWindow: 5,     // Posts per 8-hour window
  platforms: ['youtube', 'tiktok', 'facebook']
};
```

### Change Schedule

Edit **Main Orchestrator** → **Viral Scan Scheduler** node:
- Default: Every 4 hours
- Options: Every hour, Every 2 hours, Custom cron

### Content Niche

Edit **Sub-Agent: Trend Scout** → **Analyze Trends** node:

```javascript
const contentCategories = {
  entertainment: [...],
  education: [...],
  // Add your niche categories
};
```

## Troubleshooting

### Issue: "Invalid credentials"

**Solution:**
1. Verify API keys are correct
2. Check credential names match exactly
3. Re-authenticate OAuth apps

### Issue: "Rate limit exceeded"

**Solution:**
1. Add delay nodes between API calls
2. Reduce post frequency
3. Check API quota in developer console

### Issue: "Content rejected by Compliance Bot"

**Solution:**
1. Check `compliance_log` table for details
2. Review platform guidelines
3. Adjust content templates

### Issue: "No assets generated"

**Solution:**
1. Verify OpenAI/Runway API keys
2. Check API credits/billing
3. Enable fallback assets in Visual Editor

## API Rate Limits

| Platform | Limit | Reset |
|----------|-------|-------|
| YouTube | 10,000 units/day | Daily |
| TikTok | 1,000 requests/day | Daily |
| Facebook | 200 calls/hour | Hourly |
| OpenAI | Varies by tier | Monthly |

## Security Best Practices

1. ✅ Store credentials in n8n (never in workflow files)
2. ✅ Use environment variables for sensitive data
3. ✅ Enable 2FA on all social media accounts
4. ✅ Rotate API keys monthly
5. ✅ Monitor API usage for anomalies
6. ✅ Use separate API keys for production/staging

## Backup & Recovery

### Export Workflows

1. Go to **Workflows** in n8n
2. Select workflow
3. Click **Download** (top right)
4. Save JSON file

### Restore Workflows

1. Go to **Workflows** → **Import from File**
2. Select backup JSON file
3. Click **Import**

## Updating the System

1. Export current workflows as backup
2. Download updated workflow files
3. Import new workflows
4. Reconfigure credentials if needed
5. Test in staging first

## Support

### Resources

- n8n Documentation: https://docs.n8n.io
- YouTube API Docs: https://developers.google.com/youtube/v3
- TikTok API Docs: https://developers.tiktok.com/
- Facebook API Docs: https://developers.facebook.com/docs/graph-api

### Debug Mode

Enable verbose logging in any Code node:

```javascript
console.log('Debug:', JSON.stringify(data, null, 2));
```

View logs: **Settings** → **Execution Log**

## Next Steps

1. ✅ Deploy n8n instance
2. ✅ Import all workflows
3. ✅ Configure API credentials
4. ✅ Set up database (optional)
5. ✅ Activate workflows
6. ✅ Test manually
7. ✅ Monitor dashboard
8. ✅ Adjust configuration as needed

---

**Your Harry Agent Swarm is now ready to automate your social media presence!**